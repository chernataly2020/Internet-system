<!DOCTYPE html><!-- HTML5 -->
<html prefix="og: http://ogp.me/ns#" lang="ru-RU" dir="ltr">
	<head>
		<title>Продукция электротехнического завода имение В. И. Козлова - Минский электротехнический завод имени В. И. Козлова</title>
		<meta charset="utf-8" />
		<!--[if IE]><meta http-equiv="ImageToolbar" content="False" /><![endif]-->
		<meta name="generator" content="Incomedia WebSite X5 Professional 12.0.1.15 - www.websitex5.com" />
		<meta name="description" content="Продукция электротехнического завода имение В. И. Козлова" />
		<meta name="keywords" content="Продукция электротехнического завода имение В. И. Козлова" />
		<meta property="og:locale" content="ru-RU" />
		<meta property="og:type" content="website" />
		<meta property="og:url" content="http://metz.by/page3.php" />
		<meta property="og:title" content="Продукция" />
		<meta property="og:site_name" content="Минский электротехнический завод имени В. И. Козлова" />
		<meta property="og:description" content="Продукция электротехнического завода имение В. И. Козлова" />
		<meta property="og:image" content="http://metz.by/favImage.png" />
		<meta property="og:image:type" content="image/png">
		<meta property="og:image:width" content="100">
		<meta property="og:image:height" content="100">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="icon" href="favicon.png" type="image/png" />
		<link rel="stylesheet" type="text/css" href="style/reset.css" media="screen,print" />
		<link rel="stylesheet" type="text/css" href="style/print.css" media="print" />
		<link rel="stylesheet" type="text/css" href="style/style.css" media="screen,print" />
		<link rel="stylesheet" type="text/css" href="style/template.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="style/menu.css" media="screen" />
		<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="style/ie.css" media="screen" /><![endif]-->
		<link rel="stylesheet" type="text/css" href="pcss/page3.css" media="screen" />
		<!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="pcssie/page3.css" media="screen" /><![endif]-->
		<script type="text/javascript" src="res/jquery.js?15"></script>
		<script type="text/javascript" src="res/x5engine.js?15"></script>
		<script type="text/javascript">
			x5engine.boot.push(function () { x5engine.utils.checkBrowserCompatibility(); });
		</script>
		
	</head>
	<body>
		<div id="imHeaderBg"></div>
		<div id="imFooterBg"></div>
		<div id="imPage">
			<div id="imHeader">
				<h1 class="imHidden">Продукция электротехнического завода имение В. И. Козлова - Минский электротехнический завод имени В. И. Козлова</h1>
				
			</div>
			<a class="imHidden" href="#imGoToCont" title="Заголовок главного меню">Перейти к контенту</a>
			<a id="imGoToMenu"></a><p class="imHidden">Главное меню:</p>
			<div id="imMnMnGraphics"></div>
			<div id="imMnMn" class="auto">
				<div class="hamburger-site-background menu-mobile-hidden"></div><div class="hamburger-button"><div><div><div class="hamburger-bar"></div><div class="hamburger-bar"></div><div class="hamburger-bar"></div></div></div></div><div class="hamburger-menu-background-container"><div class="hamburger-menu-background menu-mobile-hidden"><div class="hamburger-menu-close-button"><span>&times;</span></div></div></div>
				<ul class="auto menu-mobile-hidden">
					<li id="imMnMnNode0" class=" imPage">
						<a href="index.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Главная</span></span>
							</span>
						</a>
					</li><li id="imMnMnNode3" class=" imPage">
						<a href="page1.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">История завода</span></span>
							</span>
						</a>
					</li><li id="imMnMnNode4" class=" imPage">
						<a href="page2.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Холдинг &quot;МЭТЗ им. В.И. Козлова&quot;</span></span>
							</span>
						</a>
					</li><li id="imMnMnNode5" class="imPage imMnMnCurrent">
						<a href="page3.php">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Продукция</span></span>
							</span>
						</a>
					</li><li id="imMnMnNode12" class=" imLevel">
						<span class="imMnMnFirstBg">
							<span class="imMnMnLevelImg"></span><span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Заказ и отгрузка продукции</span></span>
						</span>
				<ul class="auto">
					<li id="imMnMnNode13" class="imMnMnFirst imPage">
						<a href="page7.html">
							<span class="imMnMnBorder">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Заказ продукции</span></span>
							</span>
						</a>
					</li><li id="imMnMnNode14" class="imMnMnLast imPage">
						<a href="page8.html">
							<span class="imMnMnBorder">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Отгрузка продукции</span></span>
							</span>
						</a>
					</li></ul></li>
				<li id="imMnMnNode7" class=" imLevel">
						<span class="imMnMnFirstBg">
							<span class="imMnMnLevelImg"></span><span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Качество</span></span>
						</span>
				<ul class="auto">
					<li id="imMnMnNode8" class="imMnMnFirst imPage">
						<a href="page-5.html">
							<span class="imMnMnBorder">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Системы управления</span></span>
							</span>
						</a>
					</li><li id="imMnMnNode9" class="imMnMnLast imPage">
						<a href="page-9.html">
							<span class="imMnMnBorder">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Гарантии</span></span>
							</span>
						</a>
					</li></ul></li>
				<li id="imMnMnNode10" class=" imPage">
						<a href="page-6.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Партнерство</span></span>
							</span>
						</a>
					</li><li id="imMnMnNode11" class=" imPage">
						<a href="page-7.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span><span class="imMnMnTextLabel">Контакты</span></span>
							</span>
						</a>
					</li></ul>
			</div>
			<div id="imContentGraphics"></div>
			<div id="imContent">
				<a id="imGoToCont"></a>
				<h2 id="imPgTitle">Продукция электротехнического завода имение В. И. Козлова</h2>
				<div id="imGroup_1" class="imVGroup">
				<div id="imCell_1"><div id="imCellStyleGraphics_1"></div><div id="imCellStyle_1" data-responsive-sequence-number="1"><div id="imTextObject_1">
					<div class="text-tab-content"  id="imTextObject_1_tab0" style="text-align: left;">
						<div class="text-inner">
							<div><span class="fs14 ff1">Выберите интересующую Вас продукцию из списка, представленного ниже:</span></div><div><br></div><div style="line-height: 25px;"><ul><li class="ff1"><span class="fs14"><span style="line-height: 25px;"><a href="files/ktp.pdf" class="imCssLink">Комплексные трансформаторные подстанции&nbsp;</a></span><br></span></li><li class="ff1"><span class="fs14"><a href="files/st.pdf" class="imCssLink">Силовые трансформаторы</a></span></li><li class="ff1"><span class="fs14"><a href="files/tmm.pdf" class="imCssLink">Многоцелевые трансформаторы до 20 кВ*А</a></span></li><li class="ff1"><div><span class="fs14"><a href="files/ukzv.pdf" class="imCssLink">Устройства и преобразователи для защиты подземных металлических сооружений</a></span></div></li><li><div><span class="fs14 ff1"><a href="files/zapas_chasti_na_st.pdf" class="imCssLink">Запасные части для трансформаторов</a></span></div></li><li class="ff1"><div><span class="fs14"><a href="files/nomenklaturnyy.pdf" class="imCssLink">Номенклатурный каталог</a></span></div></li></ul></div>
						</div>
					</div>
				
				</div>
				</div></div><div id="imCell_2"><div id="imCellStyleGraphics_2"></div><div id="imCellStyle_2" data-responsive-sequence-number="2"><div id="imObjectGallery_2"><div id="imObjectGalleryContainer_2"></div></div><script type="text/javascript">var imObjectGallery_2_settings = {'target': '#imObjectGallery_2','backgroundColor': 'transparent','description': { 'fontSize': '9pt','fontFamily': 'Tahoma','fontStyle': 'normal','fontWeight': 'normal'},'autoplay': false,'thumbs': { 'position': 'bottom', 'number': 4 },'controlBar': { 'show': true, 'color': '#141414' },'random': false,'fullScreen': false,'media': [{'type': 'image','width': 115,'height': 230,'url': 'gallery/------------------------.png','thumb': 'gallery/------------------------_thumb.png','autoplayTime': 5000,'effect': 'none'},{'type': 'image','width': 115,'height': 230,'url': 'gallery/------------------------_z181cltd.png','thumb': 'gallery/------------------------_thumb_5z6qoty7.png','autoplayTime': 5000,'effect': 'none'},{'type': 'image','width': 115,'height': 230,'url': 'gallery/---------------------------.png','thumb': 'gallery/---------------------------_thumb.png','autoplayTime': 5000,'effect': 'none'},{'type': 'image','width': 115,'height': 230,'url': 'gallery/----------------------.png','thumb': 'gallery/----------------------_thumb.png','autoplayTime': 5000,'effect': 'none'},{'type': 'image','width': 115,'height': 230,'url': 'gallery/-------------------.png','thumb': 'gallery/-------------------_thumb.png','autoplayTime': 5000,'effect': 'none'},{'type': 'image','width': 115,'height': 230,'url': 'gallery/--------------------.png','thumb': 'gallery/--------------------_thumb.png','autoplayTime': 5000,'effect': 'none'}]};var dataimObjectGallery_2 = null;function loadimObjectGallery_2() {var startIndex = 0;if(!!dataimObjectGallery_2) {imObjectGallery_2_settings.startFrom = dataimObjectGallery_2.currentItemIndex();}var w = 0;var h = 0;var cbp = x5engine.responsive.getCurrentBreakPoint();if (cbp.fluid) {w = $('#imObjectGallery_2').innerWidth();h = w / 800 * 600;imObjectGallery_2_settings.width = wimObjectGallery_2_settings.height = h}else if (cbp.hash == 'fc23f27c1080aa74e1efeec9f2399630') {imObjectGallery_2_settings.width = 800;imObjectGallery_2_settings.height = 834;imObjectGallery_2_settings.thumbs.size = 198;}else if (cbp.hash == 'eee935b95a745d19534ef1597767c120') {imObjectGallery_2_settings.width = 800;imObjectGallery_2_settings.height = 804;imObjectGallery_2_settings.thumbs.size = 198;}else if (cbp.hash == 'b5a6e70dcd45b271d4dbff444ddeed77') {imObjectGallery_2_settings.width = 462;imObjectGallery_2_settings.height = 461;imObjectGallery_2_settings.thumbs.size = 113;}else if (cbp.hash == 'e81e7c6a4cc72fa678403ac3f73710af') {imObjectGallery_2_settings.width = 0;imObjectGallery_2_settings.height = 0;imObjectGallery_2_settings.thumbs.size = -2;}dataimObjectGallery_2 = x5engine.gallery(imObjectGallery_2_settings);$('#imContent').off('breakpointChangedOrFluid', loadimObjectGallery_2).on('breakpointChangedOrFluid', loadimObjectGallery_2);}x5engine.boot.push(loadimObjectGallery_2);</script></div></div>
				</div>
				<div id="imFooPad" style="height: 0px; float: left;">&nbsp;</div><div id="imBtMn"><a href="index.html">Главная</a> | <a href="page1.html">История завода</a> | <a href="page2.html">Холдинг &quot;МЭТЗ им. В.И. Козлова&quot;</a> | <a href="page3.php">Продукция</a> | <a href="page7.html">Заказ и отгрузка продукции</a> | <a href="page-5.html">Качество</a> | <a href="page-6.html">Партнерство</a> | <a href="page-7.html">Контакты</a> | <a href="imsitemap.html">Главная Карта Сайта</a></div>
				<div class="imClear"></div>
			</div>
			<div id="imFooter">
				
				<div id="imFooterResponsiveContent">Copyright 2015. All rights reserved.</div>
			</div>
		</div>
		<span class="imHidden"><a href="#imGoToCont" title="Прочесть эту страницу заново">Назад к содержимому</a> | <a href="#imGoToMenu" title="Прочесть этот сайт заново">Назад к главному меню</a></span>
		
		<noscript class="imNoScript"><div class="alert alert-red">Для использования этого сайта необходимо включить JavaScript.</div></noscript>
	</body>
</html>
