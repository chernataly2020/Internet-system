<?php

/*****************
	GENERAL SETTINGS
*****************/
$imSettings['search']['general'] = array(
	'menu_position' => 'left',
	'defaultScope' => array(
		'0' => 'index.html',
		'3' => 'page1.html',
		'4' => 'page2.html',
		'5' => 'page3.php',
		'8' => 'page-5.html',
		'9' => 'page-9.html',
		'10' => 'page-6.html',
		'11' => 'page-7.html',
		'13' => 'page7.html',
		'14' => 'page8.html'
	),
	'extendedScope' => array(
	)
);

/*****************
	PRODUCTS SEARCH
*****************/
$imSettings['search']['products'] = array(
);

/*****************
	IMAGES SEARCH
*****************/
$imSettings['search']['images'] = array(
);

/*****************
	VIDEOS SEARCH
*****************/
$imSettings['search']['videos'] = array(
);
$imSettings['search']['dynamicobjects'] = array(
);

// End of file search.inc.php