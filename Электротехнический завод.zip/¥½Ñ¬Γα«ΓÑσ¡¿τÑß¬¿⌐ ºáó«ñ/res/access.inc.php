<?php

// Users data
$imSettings['access']['webregistrations_gid'] = '84i56es6';
$imSettings['access']['users'] = array(
	'admin' => array(
		'groups' => array('8wgb29o2'),
		'id' => '8wgb29o2',
		'name' => 'Admin',
		'password' => 'm385p56n',
		'email' => '',
		'page' => 'index.html'
	),
	'новый пользователь' => array(
		'groups' => array('203576jr'),
		'id' => '203576jr',
		'name' => 'Новый пользователь',
		'password' => '715u286m',
		'email' => '',
		'page' => 'index.html'
	)
);

// Admins list
$imSettings['access']['admins'] = array('8wgb29o2');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php